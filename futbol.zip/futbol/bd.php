<?php


$cone=mysqli_connect("localhost","root","","presidente");

$ins="INSERT INTO presidente (nombre,apellidos,fecha_nacimiento,equipo) 
				VALUES ('$nombre', '$apellidos', '$fecha', '$presidente')";
		    	

		    	if ($cone->query($ins) === TRUE) {
					    echo "_";
					    $band_cor=1;
					} else {
					    echo "Error: " . $ins . "<br>" . $cone->error;
					}
mysqli_close($cone);


?>